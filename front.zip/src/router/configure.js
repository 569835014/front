const config={
  "店面部门管理":{
    name:"department",
    folder:"department",
    file:"",
    children:{
      "部门管理":{
        name:"departmentManage"
      }
    }
  }
}
export default config
