
export const userInfo = state => {
  return state.userInfo
};
export const keepList = state =>{
  return state.keep
};
export const activeMenu = state =>{
  return state.activeMenu
};
// export const breadcrumbList = state =>{
//   return state.breadcrumb
// };
