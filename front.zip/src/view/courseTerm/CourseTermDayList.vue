<template>
    <div class="">CourseTermDayList</div>
</template>
<script>
    export default {}
</script>
<style scoped>
</style>
