<template>
    <div class="">CourseTermStartCourseTerm</div>
</template>
<script>
    export default {}
</script>
<style scoped>
</style>
