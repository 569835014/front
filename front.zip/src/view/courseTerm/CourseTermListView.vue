<template>
    <div class="">CourseTermListView</div>
</template>
<script>
    export default {}
</script>
<style scoped>
</style>
