<template>
    <div class="">StatisticsStatisticsByTeacher</div>
</template>
<script>
    export default {}
</script>
<style scoped>
</style>
