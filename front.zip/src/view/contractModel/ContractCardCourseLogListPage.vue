<template>
  <div>ContractCardCourseLogListPage</div>
</template>
