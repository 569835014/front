<template>
    <div class="">ContractList</div>
</template>
<script>
  export default {
    created(){

    }
  }
</script>
<style scoped>
</style>
