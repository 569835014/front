<template>
    <div class="">SubjectList</div>
</template>
<script>
    export default {}
</script>
<style scoped>
</style>
