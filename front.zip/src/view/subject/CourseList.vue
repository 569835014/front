<template>
    <div class="">CourseList</div>
</template>
<script>
    export default {}
</script>
<style scoped>
</style>
