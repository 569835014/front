<template>
    <div class="">RoleRoleList</div>
</template>
<script>
    export default {}
</script>
<style scoped>
</style>
