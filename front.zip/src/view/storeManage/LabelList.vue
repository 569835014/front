<template>
    <div class="">LableList</div>
</template>
<script>
    export default {}
</script>
<style scoped>
</style>
