<template>
    <div class="class-room-list">

    </div>
</template>
<script>
    export default {
      data(){
        return{
          res:{}
        }
      },
      mounted(){

      }
    }
</script>
<style scoped>
</style>
